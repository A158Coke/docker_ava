importante:
cuando llega la pagina de log in de odoo:
gmail: admin
pass: admin
password isnt admin123    !!!!!

primer paso:
docker-compose up --build
odoo: localhost 8069 
